"""empty message

Revision ID: 1ad79b97fdcf
Revises: 852d951c9c08, adda2dd4a741
Create Date: 2024-02-28 15:11:19.999585

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '1ad79b97fdcf'
down_revision = ('852d951c9c08', 'adda2dd4a741')
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
